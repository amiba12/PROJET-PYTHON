from re import template
from django.shortcuts import render, redirect
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic import  TemplateView

from django.urls import reverse_lazy

from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.models import User
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from django_apscheduler.jobstores import DjangoJobStore, register_events
from apscheduler.jobstores.base import JobLookupError


import logging
import uuid

from django.utils import timezone
from django.core.mail import EmailMessage
from django.template.loader import render_to_string

# Imports for Reordering Feature
from django.views import View
from django.shortcuts import redirect
from django.db import transaction
from django import forms
from .models import Task
from .forms import PositionForm, TaskUpdateForm
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

logger = logging.getLogger(__name__)

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Adresse email', 'label' : 'mail'}))
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nom d’utilisateur'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Mot de passe'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirmation du mot de passe'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class Home(TemplateView):
    template_name = 'base/home.html'

def update_task_status(request):
    if request.method == "POST":
        task_id = request.POST.get("task_id")
        new_status = request.POST.get("new_status")

        try:
            task = Task.objects.get(id=task_id)
            task.statut = new_status
            task.save()
            return JsonResponse({"status": "success"}, status=200)
        except Task.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Tâche non trouvée"}, status=404)
    return JsonResponse({"status": "error", "message": "Méthode non autorisée"}, status=400)

class CustomLoginView(LoginView):
    template_name = 'base/login.html'
    fields = '__all__'
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy('tasks')


class RegisterPage(FormView):
    template_name = 'base/register.html'
    form_class = CustomUserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy('tasks')

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super(RegisterPage, self).form_valid(form)

    def get(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('tasks')
        return super(RegisterPage, self).get(*args, **kwargs)


class TaskList(LoginRequiredMixin, ListView):
    model = Task
    context_object_name = 'tasks'
    tasks = Task.objects.all()

    count = tasks.filter(statut='to-do').count()  # Compte uniquement les tâches à faire

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['tasks'] = context['tasks'].filter(user=self.request.user)


        return context

def task_list_view(request):
    tasks = Task.objects.all()
    count = tasks.filter(statut='to-do').count()  # Compte uniquement les tâches à faire
    return render(request, 'base/task_list.html', {'tasks': tasks, 'count': count})

class TaskDetail(LoginRequiredMixin, DetailView):
    model = Task
    context_object_name = 'task'
    template_name = 'base/task.html'


class TaskCreate(LoginRequiredMixin, CreateView):
    model = Task
    form_class = TaskUpdateForm
    context_object_name = 'tasks'
    # fields = ['title', 'description', 'complete']
    success_url = reverse_lazy('tasks')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(TaskCreate, self).form_valid(form)


class TaskUpdate(LoginRequiredMixin, UpdateView):
    model = Task
    form_class = TaskUpdateForm
    context_object_name = 'tasks'
    success_url = reverse_lazy('tasks')


class DeleteView(LoginRequiredMixin, DeleteView):
    model = Task
    context_object_name = 'task'
    success_url = reverse_lazy('tasks')
    def get_queryset(self):
        owner = self.request.user
        return self.model.objects.filter(user=owner)

class TaskReorder(View):
    def post(self, request):
        form = PositionForm(request.POST)

        if form.is_valid():
            positionList = form.cleaned_data["position"].split(',')

            with transaction.atomic():
                self.request.user.set_task_order(positionList)

        return redirect(reverse_lazy('tasks'))


def send_due_date_reminders_for_tomorrow():
    try:
        notes_due_tomorrow = Task.objects.filter(is_reminder_sent=False)

        for note in notes_due_tomorrow:
            if not note.is_reminder_sent:
                send_due_date_reminder_email(note)
                # note.is_reminder_sent = True
                note.save()
                
    except Exception as e:
        logger.exception("An error occurred: %s", str(e))

def send_due_date_reminder_email(Task):
    user_email = Task.user.email
    note_title = Task.title
    note_user = Task.user.username

    subject = 'Reminder: Note Due Tomorrow'
    html_message = render_to_string("base/notif.html", {'note_title': note_title, 'note_user': note_user})
    email = EmailMessage(subject, html_message, to=[user_email])
    
    if email.send():
        logger.info('Mail sent to %s', note_user)

def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_jobstore(DjangoJobStore(), "default")
    
    try:
        scheduler.remove_all_jobs()
    except Exception as e:
        logger.exception("An error occurred while clearing jobs: %s", str(e))
    
    unique_job_id = str(uuid.uuid4())

    try:
        scheduler.remove_job(unique_job_id)
    except JobLookupError:
        pass

    scheduler.add_job(
        send_due_date_reminders_for_tomorrow,
        'cron', minute='*/2'
    )
    register_events(scheduler)
    scheduler.start()
    logger.info("Scheduler started...")
