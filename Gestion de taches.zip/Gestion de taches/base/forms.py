from django import forms

# Reordering Form and View

from django import forms
from .models import *



class TaskUpdateForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(TaskUpdateForm, self).__init__(*args, **kwargs)
        self.fields["date"].widget = forms.widgets.DateInput(attrs={'type': 'date'})
        self.fields["time"].widget =  forms.widgets.TimeInput(attrs={'type': 'time'})
        

    class Meta:
        model = Task
        fields = ['title', 'description', 'date', 'time']


class PositionForm(forms.Form):
    position = forms.CharField()



