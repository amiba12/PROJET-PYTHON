from django.apps import AppConfig
import sys

class BaseConfig(AppConfig):
    name = 'base'
    def ready(self):
        if 'runserver' in sys.argv or 'uwsgi' in sys.argv:
            from .views import start_scheduler
            start_scheduler()