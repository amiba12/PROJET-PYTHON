import datetime
import schedule
import time

def output_file_exporting():
    # Your task code goes here
    print("Exporting output file...")

start_time = datetime.datetime(2024, 9, 24, 19, 5, 00)  # Your desired start time
now = datetime.datetime.now()

if now >= start_time:
    next_exec_time = start_time + datetime.timedelta(minutes=1)
else:
    next_exec_time = start_time

while True:
    if datetime.datetime.now() >= next_exec_time:
        output_file_exporting()
        next_exec_time += datetime.timedelta(minutes=10)
    time.sleep(1)